#!/usr/bin/python3
import sys
import json

import run

Q = run.cosine_similarity(int(sys.argv[1]), str(sys.argv[2]))

